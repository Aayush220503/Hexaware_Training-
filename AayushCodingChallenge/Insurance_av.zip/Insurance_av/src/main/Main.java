package main;

import java.sql.*;

import com.hexaware.dao.InsuranceServiceImpl;
import com.hexaware.entity.Policy;
import com.hexaware.exception.PolicyNotFoundException;
import com.hexaware.util.DBConnUtil;
import com.hexaware.util.DBPropertyUtil;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InsuranceServiceImpl service = new InsuranceServiceImpl();
        int choice;
        do {
            System.out.println("\n--- Welcome to your Insurance Management System ---");
            System.out.println("1. Create Policy");
            System.out.println("2. View Policy by ID");
            System.out.println("3. View All Policies");
            System.out.println("4. Update Policy");
            System.out.println("5. Delete Policy");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            try {
                switch (choice) {
                    case 1 -> {
                        System.out.println("Enter policy details:");
                        System.out.print("Policy ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Policy Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Coverage Amount: ");
                        double coverage = scanner.nextDouble();
                        System.out.print("Premium: ");
                        double premium = scanner.nextDouble();
                        System.out.print("Term (in years): ");
                        int term = scanner.nextInt();

                        Policy newPolicy = new Policy(id, name, coverage, premium, term);
                        boolean created = service.createPolicy(newPolicy);
                        System.out.println(created ? "Policy created successfully." : "Failed to create policy.");
                    }
                    case 2 -> {
                        System.out.print("Enter Policy ID: ");
                        int id = scanner.nextInt();
                        Policy policy = service.getPolicy(id);
                        System.out.println("Policy Details:\n" + policy);
                    }
                    case 3 -> {
                        List<Policy> policies = service.getAllPolicies();
                        if (policies.isEmpty()) {
                            System.out.println("No policies found.");
                        } else {
                            policies.forEach(System.out::println);
                        }
                    }
                    case 4 -> {
                        System.out.println("Enter policy details to update:");
                        System.out.print("Policy ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();  
                        System.out.print("New Policy Name: ");
                        String name = scanner.nextLine();
                        System.out.print("New Coverage Amount: ");
                        double coverage = scanner.nextDouble();
                        System.out.print("New Premium: ");
                        double premium = scanner.nextDouble();
                        System.out.print("New Term (in years): ");
                        int term = scanner.nextInt();

                        Policy updatedPolicy = new Policy(id, name, coverage, premium, term);
                        boolean updated = service.updatePolicy(updatedPolicy);
                        System.out.println(updated ? "Policy updated successfully." : "Failed to update policy.");
                    }
                    case 5 -> {
                        System.out.print("Enter Policy ID to delete: ");
                        int id = scanner.nextInt();
                        boolean deleted = service.deletePolicy(id);
                        System.out.println(deleted ? "Policy deleted successfully." : "Failed to delete policy.");
                    }
                    case 6 -> System.out.println("Exiting application. Goodbye!");

                    default -> System.out.println("Invalid choice.Try again.");
                }
            } catch (PolicyNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }

        } while (choice != 6);

        scanner.close();
    }
}
