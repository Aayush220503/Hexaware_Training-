package com.hexaware.entity;


public class Client {
	private int clientId;
	private String clientName;
	private String contactinfo;
	private Policy policy;
	
	public Client(int clientId, String clientName, String contactInfo, Policy policy) {
        this.clientId = clientId;
        this.clientName = clientName;
        this.contactinfo = contactInfo;
        this.policy = policy;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getContactInfo() {
        return contactinfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactinfo = contactInfo;
    }

    public Policy getPolicy() {
        return policy;
    }

    public void setPolicy(Policy policy) {
        this.policy = policy;
    }

    @Override
    public String toString() {
        return "Client ID: " + clientId +
                ", Name: " + clientName +
                ", Contact Info: " + contactinfo +
                ", Policy: [" + policy.toString() + "]";
    }

}
