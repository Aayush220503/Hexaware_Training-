package com.hexaware.entity;

public class Policy {
    private int policyId;
    private String policyName;
    private double coverageAmount;
    private double premium;
    private int term;

    public Policy(int policyId, String policyName, double coverageAmount, double premium, int term) {
        this.policyId = policyId;
        this.policyName = policyName;
        this.coverageAmount = coverageAmount;
        this.premium = premium;
        this.term = term;
    }

    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public double getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    @Override
    public String toString() {
        return "Policy [ID=" + policyId + ", Name=" + policyName +
               ", Coverage=$" + coverageAmount + ", Premium=$" + premium +
               ", Term=" + term + " years]";
    }
}

