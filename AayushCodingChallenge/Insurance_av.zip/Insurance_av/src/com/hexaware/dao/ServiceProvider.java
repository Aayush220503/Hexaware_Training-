package com.hexaware.dao;
/*
 public interface IPolicyService {
    boolean createPolicy(Policy policy);
    Policy getPolicy(int policyId) throws PolicyNotFoundException;
    List<Policy> getAllPolicies();
    boolean updatePolicy(Policy policy);
    boolean deletePolicy(int policyId) throws PolicyNotFoundException;
}

 */
import java.util.*;

import com.hexaware.entity.Policy;
import com.hexaware.exception.PolicyNotFoundException;
public interface ServiceProvider {
	boolean createPolicy(Policy policy);
	Policy getPolicy(int policyId) throws PolicyNotFoundException;
    List<Policy> getAllPolicies();
    boolean updatePolicy(Policy policy);
    boolean deletePolicy(int policyId) throws PolicyNotFoundException;

}
