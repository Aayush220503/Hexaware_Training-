package com.hexaware.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.entity.Policy;
import com.hexaware.exception.PolicyNotFoundException;
import com.hexaware.util.DBConnUtil;

public class InsuranceServiceImpl implements IPolicyService {

    private Connection connection;

    public InsuranceServiceImpl() {
        this.connection = DBConnUtil.getConnection("E:\\Insurance_av\\src\\com\\hexaware\\util\\db.properties");
    }

    @Override
    public boolean createPolicy(Policy policy) {
        String sql = "INSERT INTO Policy (policyId, policyName, coverageAmount, premium, term) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, policy.getPolicyId());
            ps.setString(2, policy.getPolicyName());
            ps.setDouble(3, policy.getCoverageAmount());
            ps.setDouble(4, policy.getPremium());
            ps.setInt(5, policy.getTerm());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Policy getPolicy(int policyId) throws PolicyNotFoundException {
        String sql = "SELECT * FROM Policy WHERE policyId = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, policyId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getDouble("coverageAmount"),
                    rs.getDouble("premium"),
                    rs.getInt("term")
                );
            } else {
                throw new PolicyNotFoundException("Policy ID " + policyId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new PolicyNotFoundException("Error retrieving policy.");
        }
    }

    @Override
    public List<Policy> getAllPolicies() {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM Policy";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                policies.add(new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getDouble("coverageAmount"),
                    rs.getDouble("premium"),
                    rs.getInt("term")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policies;
    }

    @Override
    public boolean updatePolicy(Policy policy) {
        String sql = "UPDATE Policy SET policyName=?, coverageAmount=?, premium=?, term=? WHERE policyId=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, policy.getPolicyName());
            ps.setDouble(2, policy.getCoverageAmount());
            ps.setDouble(3, policy.getPremium());
            ps.setInt(4, policy.getTerm());
            ps.setInt(5, policy.getPolicyId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deletePolicy(int policyId) throws PolicyNotFoundException {
        String sql = "DELETE FROM Policy WHERE policyId = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, policyId);
            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new PolicyNotFoundException("Policy ID " + policyId + " not found.");
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new PolicyNotFoundException("Error deleting policy.");
        }
    }
}
